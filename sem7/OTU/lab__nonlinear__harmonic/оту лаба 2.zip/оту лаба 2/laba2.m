clc;
clear variables;
close all;
y_mem = 0;
b = 1; % приделы гистерезиса
c = 1; % выходное значение
d = 15.5;
% полученная амплетуда: 8.3
% полученная частота: гц 0.665 в циклической 4.178

q1(8.3)
q2(8.3) 

function y = rele(x)
    global b;
    global c; 
    global y_mem;
    if x > b
        y_mem = c;
    end
    if x < -b
        y_mem = -c;
    end
    y = y_mem;
end

function q = q1(a)

    q = (4)/(pi*a)*sqrt(1 - 1/a^2);
end

function q_shtih = q2(a)

    q_shtih = -(4)/(pi*a^2);
end